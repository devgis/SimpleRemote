﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SimpleRemote.Modes
{
    public class DbPuttyColor
    {
        public string id { get; set; }
        public int Colour0 { get; set; }
        public int Colour1 { get; set; }
        public int Colour2 { get; set; }
        public int Colour3 { get; set; }
        public int Colour4 { get; set; }
        public int Colour5 { get; set; }
        public int Colour6 { get; set; }
        public int Colour7 { get; set; }
        public int Colour8 { get; set; }
        public int Colour9 { get; set; }
        public int Colour10 { get; set; }
        public int Colour11 { get; set; }
        public int Colour12 { get; set; }
        public int Colour13 { get; set; }
        public int Colour14 { get; set; }
        public int Colour15 { get; set; }
        public int Colour16 { get; set; }
        public int Colour17 { get; set; }
        public int Colour18 { get; set; }
        public int Colour19 { get; set; }
        public int Colour20 { get; set; }
        public int Colour21 { get; set; }
    }
}
