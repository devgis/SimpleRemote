﻿using System.Windows.Controls;

namespace SimpleRemote.Controls.Dragablz
{
    public class VerticalOrganiser : StackOrganiser
    {
        public VerticalOrganiser() : base(Orientation.Vertical)
        {
        }
    }
}