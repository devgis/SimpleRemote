﻿namespace SimpleRemote.Controls.Dragablz.Dockablz
{
    public enum BranchItem
    {
        First,
        Second
    }
}