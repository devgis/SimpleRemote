﻿using System.Windows.Controls;

namespace SimpleRemote.Controls.Dragablz
{
    public class HorizontalPositionMonitor : StackPositionMonitor
    {
        public HorizontalPositionMonitor() : base(Orientation.Horizontal)
        {
        }
    }
}