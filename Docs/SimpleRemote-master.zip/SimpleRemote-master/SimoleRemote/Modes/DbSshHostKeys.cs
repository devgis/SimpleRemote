﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SimpleRemote.Modes
{
    public class DbSshHostKeys
    {
        public string id { get; set; }
        public byte[] value { get; set; }
    }
}
