﻿using System.Windows.Controls;

namespace SimpleRemote.Controls.Dragablz
{
    public class VerticalPositionMonitor : StackPositionMonitor
    {
        public VerticalPositionMonitor() : base(Orientation.Vertical)
        {
        }
    }
}